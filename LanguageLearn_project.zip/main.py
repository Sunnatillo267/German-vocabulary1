import os

from kivy.app import App
from kivy.core.text import LabelBase
from kivy.core.window import Window
from kivy.lang import Builder
from kivy.metrics import dp
from kivy.properties import ListProperty, StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.screenmanager import Screen, SlideTransition

import ll_core

# ✓ ✕ ♪ ✖ ↻ belgilari uchun: fonts/DejaVuSans.ttf (yoki NotoEmoji) ni loyihaga qo'shing
_FONT = os.path.join(os.path.dirname(__file__), "fonts", "DejaVuSans.ttf")
if os.path.exists(_FONT):
    LabelBase.register("Roboto", _FONT)

Window.clearcolor = (0.957, 0.965, 0.984, 1)

BLUE = (0.18, 0.42, 1, 1)
GREY = (0.55, 0.58, 0.65, 1)
RED = (0.90, 0.28, 0.30, 1)
GREEN = (0.18, 0.64, 0.31, 1)
INK = (0.10, 0.12, 0.18, 1)

KV = """
<RBtn>:
    background_normal: ''
    background_down: ''
    background_color: 0, 0, 0, 0
    color: 1, 1, 1, 1
    bold: True
    font_size: '16sp'
    size_hint_y: None
    height: dp(50)
    canvas.before:
        Color:
            rgba: self.bg if self.state == 'normal' else (self.bg[0]*.82, self.bg[1]*.82, self.bg[2]*.82, 1)
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(14)]

<Chip>:
    background_normal: ''
    background_down: ''
    background_color: 0, 0, 0, 0
    font_size: '14sp'
    bold: True
    size_hint_y: None
    height: dp(42)
    color: (1, 1, 1, 1) if self.state == 'down' else (.18, .42, 1, 1)
    canvas.before:
        Color:
            rgba: (.18, .42, 1, 1) if self.state == 'down' else (.88, .92, 1, 1)
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(21)]

<Tab>:
    background_normal: ''
    background_down: ''
    background_color: 0, 0, 0, 0
    bold: True
    font_size: '16sp'
    color: (1, 1, 1, 1) if self.state == 'down' else (.78, .85, 1, 1)
    canvas.before:
        Color:
            rgba: (1, 1, 1, .18) if self.state == 'down' else (0, 0, 0, 0)
        RoundedRectangle:
            pos: self.x + dp(4), self.y + dp(6)
            size: self.width - dp(8), self.height - dp(12)
            radius: [dp(12)]

<Field@TextInput>:
    multiline: False
    size_hint_y: None
    height: dp(50)
    padding: dp(14), dp(14)
    font_size: '17sp'
    background_normal: ''
    background_active: ''
    background_color: 1, 1, 1, 1
    foreground_color: .1, .12, .18, 1
    hint_text_color: .6, .63, .7, 1
    cursor_color: .18, .42, 1, 1

<Card@BoxLayout>:
    orientation: 'vertical'
    padding: dp(14)
    spacing: dp(10)
    size_hint_y: None
    height: self.minimum_height
    canvas.before:
        Color:
            rgba: 1, 1, 1, 1
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(18)]

<H@Label>:
    color: .1, .12, .18, 1
    bold: True
    font_size: '17sp'
    size_hint_y: None
    height: dp(26)
    text_size: self.width, None
    halign: 'left'

<Root>:
    orientation: 'vertical'
    BoxLayout:
        size_hint_y: None
        height: dp(60)
        padding: dp(8), dp(4)
        canvas.before:
            Color:
                rgba: .18, .42, 1, 1
            Rectangle:
                pos: self.pos
                size: self.size
        Tab:
            id: t0
            text: "So'zlar"
            group: 'tabs'
            state: 'down'
            allow_no_selection: False
            on_release: root.go('words')
        Tab:
            id: t1
            text: 'Tarix'
            group: 'tabs'
            allow_no_selection: False
            on_release: root.go('history')
        Tab:
            id: t2
            text: 'Test'
            group: 'tabs'
            allow_no_selection: False
            on_release: root.go('test')
    ScreenManager:
        id: sm
        WordsScreen:
            name: 'words'
        HistoryScreen:
            name: 'history'
        TestScreen:
            name: 'test'
"""

from kivy.uix.togglebutton import ToggleButton  # noqa: E402


class RBtn(Button):
    bg = ListProperty(BLUE)


class Chip(ToggleButton):
    pass


class Tab(ToggleButton):
    pass


def lbl(text, color=INK, size="15sp", bold=False, h=None):
    l = Label(text=text, color=color, font_size=size, bold=bold, size_hint_y=None,
              halign="left", valign="middle", markup=True)
    l.bind(width=lambda w, v: setattr(w, "text_size", (v, None)))
    l.bind(texture_size=lambda w, v: setattr(w, "height", h or max(dp(24), v[1] + dp(4))))
    return l


def confirm(title, msg, on_yes):
    box = BoxLayout(orientation="vertical", padding=dp(16), spacing=dp(14))
    box.add_widget(lbl(msg, size="16sp"))
    row = BoxLayout(spacing=dp(10), size_hint_y=None, height=dp(50))
    pop = Popup(title=title, content=box, size_hint=(.88, None), height=dp(240),
                separator_color=BLUE)
    no = RBtn(text="Bekor qilish", bg=GREY)
    yes = RBtn(text="Ha, o'chirish", bg=RED)
    no.bind(on_release=pop.dismiss)
    yes.bind(on_release=lambda *_: (pop.dismiss(), on_yes()))
    row.add_widget(no)
    row.add_widget(yes)
    box.add_widget(row)
    pop.open()


def scroll_col():
    from kivy.uix.scrollview import ScrollView
    sv = ScrollView(bar_width=dp(3))
    col = BoxLayout(orientation="vertical", spacing=dp(10), padding=dp(14), size_hint_y=None)
    col.bind(minimum_height=col.setter("height"))
    sv.add_widget(col)
    return sv, col


def spinner(values, text):
    from kivy.uix.spinner import Spinner
    return Spinner(text=text, values=values, size_hint_y=None, height=dp(48),
                   background_normal="", background_color=(1, 1, 1, 1), color=INK,
                   font_size="16sp", bold=True)


# ---------------- Ekranlar ----------------
class WordsScreen(Screen):
    def on_kv_post(self, *a):
        sv, col = scroll_col()
        self.add_widget(sv)
        card = Builder.load_string("Card:")
        card.add_widget(Builder.load_string("H:\n    text: \"Yangi so'z\""))
        self.de = Builder.load_string("Field:\n    hint_text: \"Nemischa so'z (masalan: das Haus)\"")
        self.uz = Builder.load_string("Field:\n    hint_text: \"O'zbekcha tarjimasi\"")
        self.de.bind(on_text_validate=lambda *_: setattr(self.uz, "focus", True))
        self.uz.bind(on_text_validate=lambda *_: self.add())
        listen = RBtn(text="♪ Eshitish", bg=(.35, .38, .46, 1), height=dp(44))
        listen.bind(on_release=lambda *_: App.get_running_app().core.speak(self.de.text))
        add = RBtn(text="Qo'shish", bg=BLUE)
        add.bind(on_release=lambda *_: self.add())
        fbtn = RBtn(text="Fayldan qo'shish  (docx / csv / txt)", bg=GREY)
        fbtn.bind(on_release=lambda *_: self.pick_file())
        for w in (self.de, self.uz, listen, add, fbtn):
            card.add_widget(w)
        col.add_widget(card)
        col.add_widget(lbl("Oxirgi qo'shilgan so'zlar", bold=True, size="17sp"))
        self.box = BoxLayout(orientation="vertical", spacing=dp(6), size_hint_y=None)
        self.box.bind(minimum_height=self.box.setter("height"))
        col.add_widget(self.box)

    def on_pre_enter(self, *a):
        self.refresh()

    def add(self):
        core = App.get_running_app().core
        r = core.add_word(self.de.text, self.uz.text)
        if r != "empty":
            self.de.text = self.uz.text = ""
            self.de.focus = True
        self.refresh()

    def pick_file(self):
        try:
            from plyer import filechooser
            filechooser.open_file(on_selection=self._picked,
                                  filters=[["Fayllar", "*.docx", "*.csv", "*.txt"]])
        except Exception as e:
            self.box.clear_widgets()
            self.box.add_widget(lbl(f"Fayl tanlab bo'lmadi: {e}", color=RED))

    def _picked(self, sel):
        if sel:
            App.get_running_app().core.add_from_file(sel[0])
            self.refresh()

    def refresh(self):
        self.box.clear_widgets()
        rec = App.get_running_app().core.recent[:30]
        if not rec:
            self.box.add_widget(lbl("Hozircha bo'sh", color=GREY))
        for de, uz, st in rec:
            row = BoxLayout(size_hint_y=None, height=dp(46), padding=(dp(12), 0), spacing=dp(8))
            col = GREEN if st == "new" else RED
            from kivy.graphics import Color, RoundedRectangle
            with row.canvas.before:
                Color(1, 1, 1, 1)
                bg = RoundedRectangle(radius=[dp(12)])
            row.bind(pos=lambda w, v, b=bg: setattr(b, "pos", v),
                     size=lambda w, v, b=bg: setattr(b, "size", v))
            mark = Label(text="✓" if st == "new" else "✕", color=col, bold=True,
                         size_hint_x=None, width=dp(24), font_size="18sp")
            t = lbl(f"{de}  —  {uz}" + ("" if st == "new" else "   [color=#E5484D](takror)[/color]"))
            t.size_hint_y = 1
            row.add_widget(mark)
            row.add_widget(t)
            self.box.add_widget(row)


class HistoryScreen(Screen):
    def on_kv_post(self, *a):
        sv, col = scroll_col()
        self.add_widget(sv)
        self.sp = spinner([], "")
        self.sp.bind(text=lambda *_: self.render())
        col.add_widget(self.sp)
        r = BoxLayout(spacing=dp(8), size_hint_y=None, height=dp(50))
        d = RBtn(text="✖ Kunni o'chirish", bg=RED, font_size="14sp")
        c = RBtn(text="✖ Tarixni tozalash", bg=RED, font_size="14sp")
        d.bind(on_release=lambda *_: confirm(
            "Kunni o'chirish", f"{self.sp.text} kunidagi natijalar o'chirilsinmi?", self.del_day))
        c.bind(on_release=lambda *_: confirm(
            "Tarixni tozalash", "Butun tarix o'chiriladi. Davom etamizmi?", self.clear))
        r.add_widget(d)
        r.add_widget(c)
        col.add_widget(r)
        self.box = BoxLayout(orientation="vertical", spacing=dp(10), size_hint_y=None)
        self.box.bind(minimum_height=self.box.setter("height"))
        col.add_widget(self.box)

    def on_pre_enter(self, *a):
        core = App.get_running_app().core
        self.sp.values = core.dates()
        if self.sp.text not in self.sp.values:
            self.sp.text = self.sp.values[0]
        self.render()

    def del_day(self):
        App.get_running_app().core.delete_day(self.sp.text)
        self.on_pre_enter()

    def clear(self):
        App.get_running_app().core.clear_history()
        self.on_pre_enter()

    def render(self):
        self.box.clear_widgets()
        rows = App.get_running_app().core.history(self.sp.text) if self.sp.text else []
        if not rows:
            self.box.add_widget(lbl("Bu kunda so'zlar yo'q", color=GREY))
        for r in rows:
            card = Builder.load_string("Card:")
            w = r["word"]
            card.add_widget(lbl(f"[b]{w['de']}[/b]  —  {w['uz']}", size="16sp"))
            good = r["state"].startswith("✓")
            card.add_widget(lbl(
                f"[color=#2EA44F]to'g'ri: {r['ok']}[/color]   [color=#E5484D]noto'g'ri: {r['bad']}[/color]"
                f"   oxirgi to'g'ri: {r['last_ok']}", size="13sp", color=GREY))
            card.add_widget(lbl(r["state"], bold=True,
                                color=GREEN if good else (.85, .5, .1, 1)))
            self.box.add_widget(card)


class TestScreen(Screen):
    mode = StringProperty("all")
    cat = StringProperty("all")
    q = None

    def on_kv_post(self, *a):
        sv, col = scroll_col()
        self.add_widget(sv)
        self.col = col
        self.build_setup()

    def on_pre_enter(self, *a):
        self.sp.values = App.get_running_app().core.dates()
        if self.sp.text not in self.sp.values:
            self.sp.text = ll_core.today()

    def build_setup(self):
        c = self.col
        c.clear_widgets()
        self.sp = spinner(App.get_running_app().core.dates(), ll_core.today())
        c.add_widget(lbl("Sana", bold=True))
        c.add_widget(self.sp)
        c.add_widget(lbl("Rejim", bold=True))
        r = BoxLayout(spacing=dp(8), size_hint_y=None, height=dp(42))
        for key, t in (("all", "Barcha"), ("wrong", "Faqat xato")):
            b = Chip(text=t, group="mode", state="down" if key == self.mode else "normal",
                     allow_no_selection=False)
            b.bind(on_release=lambda w, k=key: setattr(self, "mode", k))
            r.add_widget(b)
        c.add_widget(r)
        c.add_widget(lbl("Turkum", bold=True))
        cats = [("all", "Hammasi"), ("nomen", "Nomen"), ("verben", "Verben"),
                ("verb_verb", "Verb + Verbindung"), ("praep", "Präpositionen")]
        for chunk in (cats[:3], cats[3:]):
            r = BoxLayout(spacing=dp(8), size_hint_y=None, height=dp(42))
            for key, t in chunk:
                b = Chip(text=t, group="cat", state="down" if key == self.cat else "normal",
                         allow_no_selection=False, font_size="13sp")
                b.bind(on_release=lambda w, k=key: setattr(self, "cat", k))
                r.add_widget(b)
            c.add_widget(r)
        self.msg = lbl("", color=RED)
        c.add_widget(self.msg)
        go = RBtn(text="Testni boshlash", bg=BLUE)
        go.bind(on_release=lambda *_: self.start())
        c.add_widget(go)

    def start(self):
        self.date = self.sp.text
        self.ask()

    def ask(self):
        core = App.get_running_app().core
        q = core.next_question(self.date, self.mode, self.cat)
        if not q:
            self.msg.text = "Bu tanlov bo'yicha so'z topilmadi"
            return
        self.q = q
        c = self.col
        c.clear_widgets()
        card = Builder.load_string("Card:")
        card.add_widget(lbl(ll_core.CATS[q["cat"]], color=BLUE, bold=True, size="13sp"))
        p = lbl(q["prompt"], size="26sp", bold=True)
        card.add_widget(p)
        card.add_widget(lbl(q["hint"], color=GREY))
        c.add_widget(card)
        self.inp = Builder.load_string("Field:\n    hint_text: 'Javobingiz'")
        self.inp.bind(on_text_validate=lambda *_: self.check())
        c.add_widget(self.inp)
        self.chk = RBtn(text="Tekshirish", bg=BLUE)
        self.chk.bind(on_release=lambda *_: self.check())
        c.add_widget(self.chk)
        self.res = lbl("", size="18sp", bold=True)
        c.add_widget(self.res)
        self.inp.focus = True

    def check(self):
        if self.chk.disabled:
            return
        ok, shown = App.get_running_app().core.check(self.q, self.inp.text)
        self.chk.disabled = True
        self.inp.readonly = True
        if ok:
            self.res.text = "✓ To'g'ri!"
            self.res.color = GREEN
        else:
            self.res.text = f"✕ {self.inp.text or '—'}   To'g'ri javob: {shown}"
            self.res.color = RED
        more = RBtn(text="Yana", bg=GREEN)
        more.bind(on_release=lambda *_: self.ask())
        stop = RBtn(text="Tugatish", bg=GREY, height=dp(44))
        stop.bind(on_release=lambda *_: self.build_setup())
        self.col.add_widget(more)
        self.col.add_widget(stop)


class Root(BoxLayout):
    def go(self, name):
        sm = self.ids.sm
        order = ["words", "history", "test"]
        sm.transition = SlideTransition(
            direction="left" if order.index(name) > order.index(sm.current) else "right",
            duration=0.18)
        sm.current = name


class LanguageLearnApp(App):
    title = "Language Learn"

    def build(self):
        self.core = ll_core.Core(self.user_data_dir)
        Builder.load_string(KV)
        return Root()


if __name__ == "__main__":
    LanguageLearnApp().run()
