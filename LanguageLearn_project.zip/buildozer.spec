[app]
title = Language Learn
package.name = languagelearn
package.domain = org.sunnat
source.dir = .
source.include_exts = py,png,jpg,kv,ttf,json
version = 1.0
requirements = python3,kivy==2.3.0,plyer,pyjnius,android
orientation = portrait
fullscreen = 0
android.permissions = READ_EXTERNAL_STORAGE,READ_MEDIA_DOCUMENTS
android.api = 34
android.minapi = 24
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True
android.enable_androidx = True

[buildozer]
log_level = 2
warn_on_root = 1
