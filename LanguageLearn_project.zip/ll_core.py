"""ll_core.py — Language Learn mantiq qatlami (UI'dan mustaqil).

Turkumlar: nomen, verben, verb_verb, praep
"""
import datetime
import json
import os
import random
import re
import unicodedata

CATS = {
    "nomen": "Nomen",
    "verben": "Verben",
    "verb_verb": "Verb + Verbindung",
    "praep": "Präpositionen",
}
CASES = {"A": "Akkusativ", "D": "Dativ", "G": "Genitiv"}
APOS = "ʻʼ’‘`´"


def today():
    return datetime.date.today().isoformat()


# ---------- matn normallashtirish va baholash ----------
def norm(s):
    s = unicodedata.normalize("NFC", str(s)).lower().strip()
    for a in APOS:
        s = s.replace(a, "'")
    s = s.replace("ß", "ss")
    s = re.sub(r"[.!?;:,\"]+$", "", s)
    return re.sub(r"\s+", " ", s).strip()


def _fold(s):
    s = norm(s)
    for a, b in (("ä", "a"), ("ö", "o"), ("ü", "u")):
        s = s.replace(a, b)
    return s


def _lev(a, b):
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def _variants(ans):
    out = set()
    for part in re.split(r"[,;/|]", ans):
        base = re.sub(r"\(.*?\)", "", part)
        for p in (part, base):
            p = norm(p)
            if p:
                out.add(p)
                out.add(re.sub(r"^(to|sich) ", "", p))
    return out


def judge(user, answer, kind="text"):
    """Moslashuvchan baholash. kind='case' bo'lsa kasus qisqartmalari qabul qilinadi."""
    u = norm(user)
    if not u:
        return False
    if kind == "case":
        key = answer.upper()
        names = {"A": ["a", "akk", "akkusativ", "4"], "D": ["d", "dat", "dativ", "3"],
                 "G": ["g", "gen", "genitiv", "2"]}
        for k in key.split("/"):
            if k in names and u.strip(".") in names[k]:
                return True
        return False
    for v in _variants(answer):
        if u == v or _fold(u) == _fold(v):
            return True
        if len(v) >= 5 and _lev(_fold(u), _fold(v)) <= 1:  # kamchilik kechiriladi
            return True
    return False


# ---------- so'zni tahlil qilish ----------
RE_ART = re.compile(r"^(der|die|das)\s+(.+)$", re.I)
RE_VV = re.compile(r"^(.+?)\s*\(\s*(\w+)\s*\+\s*([ADG])\.?\s*\)$", re.I)
RE_PR = re.compile(r"^(\w+)\s*\(\s*([ADG](?:/[ADG])*)\.?\s*\)$", re.I)


def detect_cat(de):
    de = de.strip()
    if RE_ART.match(de):
        return "nomen"
    if RE_VV.match(de):
        return "verb_verb"
    if RE_PR.match(de):
        return "praep"
    return "verben"


class Core:
    def __init__(self, folder="."):
        self.path = os.path.join(folder, "ll_data.json")
        self.data = {"words": [], "log": [], "next": 1}
        self.recent = []
        if os.path.exists(self.path):
            try:
                with open(self.path, encoding="utf-8") as f:
                    self.data = json.load(f)
            except Exception:
                pass

    def save(self):
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False)

    # ----- so'z qo'shish -----
    def add_word(self, de, uz):
        de, uz = de.strip(), uz.strip()
        if not de or not uz:
            return "empty"
        for w in self.data["words"]:
            if norm(w["de"]) == norm(de):
                self.recent.insert(0, (de, uz, "dup"))
                return "dup"
        w = {"id": self.data["next"], "de": de, "uz": uz,
             "cat": detect_cat(de), "added": today()}
        self.data["next"] += 1
        self.data["words"].append(w)
        self.recent.insert(0, (de, uz, "new"))
        self.save()
        return "new"

    def add_from_file(self, path):
        ext = os.path.splitext(path)[1].lower()
        lines = []
        if ext == ".docx":
            import zipfile
            import html as _h
            with zipfile.ZipFile(path) as z:
                xml = z.read("word/document.xml").decode("utf-8", "ignore")
            # jadval qatorlari: katakchalar ";" bilan, oddiy abzatslar alohida qator
            def _txt(x):
                x = re.sub(r"</w:tab>|<w:tab/>", "\t", x)
                return _h.unescape(re.sub(r"<[^>]+>", "", x)).strip()
            for tr in re.findall(r"<w:tr[ >].*?</w:tr>", xml, flags=re.S):
                cells = [_txt(c) for c in re.findall(r"<w:tc[ >].*?</w:tc>", tr, flags=re.S)]
                if len(cells) >= 2:
                    lines.append(cells[0] + ";" + cells[1])
            xml_np = re.sub(r"<w:tbl>.*?</w:tbl>", "", xml, flags=re.S)
            for p in re.findall(r"<w:p[ >].*?</w:p>", xml_np, flags=re.S):
                lines.append(_txt(p))
        else:
            with open(path, encoding="utf-8-sig", errors="ignore") as f:
                lines = f.read().splitlines()
        res = {"new": 0, "dup": 0, "skip": 0}
        for ln in lines:
            ln = ln.strip()
            if not ln:
                continue
            parts = re.split(r"\t|;|\s[-–—=]\s", ln, maxsplit=1)
            if len(parts) < 2 and "," in ln:
                parts = ln.split(",", 1)
            if len(parts) < 2:
                res["skip"] += 1
                continue
            r = self.add_word(parts[0], parts[1])
            res[r] = res.get(r, 0) + 1
        return res

    # ----- tarix -----
    def log(self, wid, ok):
        self.data["log"].append({"wid": wid, "date": today(), "ok": bool(ok),
                                 "ts": datetime.datetime.now().isoformat(timespec="seconds")})
        self.save()

    def dates(self):
        ds = {l["date"] for l in self.data["log"]} | {w["added"] for w in self.data["words"]}
        ds.add(today())
        return sorted(ds, reverse=True)

    def _word(self, wid):
        return next((w for w in self.data["words"] if w["id"] == wid), None)

    def history(self, date):
        rows = {}
        for w in self.data["words"]:
            if w["added"] == date:
                rows[w["id"]] = []
        for l in self.data["log"]:
            if l["date"] == date:
                rows.setdefault(l["wid"], []).append(l)
        out = []
        for wid, ls in rows.items():
            w = self._word(wid)
            if not w:
                continue
            good = [l for l in ls if l["ok"]]
            bad = len(ls) - len(good)
            last_ok = bool(ls) and ls[-1]["ok"]
            out.append({
                "word": w, "ok": len(good), "bad": bad,
                "last_ok": good[-1]["ts"][11:16] if good else "—",
                "state": "✓ Yodlangan" if (last_ok and len(good) >= bad) else "↻ Takrorlash",
            })
        out.sort(key=lambda r: (r["state"][0] == "✓", r["word"]["de"].lower()))
        return out

    def delete_day(self, date):
        self.data["log"] = [l for l in self.data["log"] if l["date"] != date]
        self.data["words"] = [w for w in self.data["words"] if w["added"] != date
                              or any(l["wid"] == w["id"] for l in self.data["log"])]
        self.save()

    def clear_history(self):
        self.data["log"] = []
        self.save()

    # ----- test -----
    def pool(self, date, mode, cat):
        ids = {r["word"]["id"]: r for r in self.history(date)}
        ws = [r["word"] for r in ids.values()
              if mode == "all" or r["state"].startswith("↻") and r["bad"] > 0]
        if cat != "all":
            ws = [w for w in ws if w["cat"] == cat]
        return ws

    def question(self, word):
        de, uz, cat = word["de"], word["uz"], word["cat"]
        q = {"wid": word["id"], "cat": cat, "kind": "text"}
        m = RE_ART.match(de)
        if cat == "nomen" and m:
            q.update(prompt=f"___ {m.group(2)}", hint=uz, answer=m.group(1).lower())
        elif cat == "verb_verb" and RE_VV.match(de):
            m = RE_VV.match(de)
            q.update(prompt=f"{m.group(1)} (___ + {m.group(3).upper()}.)", hint=uz,
                     answer=m.group(2).lower())
        elif cat == "praep" and RE_PR.match(de):
            m = RE_PR.match(de)
            q.update(prompt=f"{m.group(1)} — qaysi kasus bilan? (A. / D. / G.)", hint=uz,
                     answer=m.group(2).upper(), kind="case")
        else:
            q.update(prompt=f"{uz}", hint="nemischa?", answer=re.sub(r"\(.*?\)", "", de).strip())
        return q

    def next_question(self, date, mode, cat):
        ws = self.pool(date, mode, cat)
        return self.question(random.choice(ws)) if ws else None

    def check(self, q, user):
        ok = judge(user, q["answer"], q["kind"])
        self.log(q["wid"], ok)
        shown = CASES.get(q["answer"], q["answer"]) if q["kind"] == "case" else q["answer"]
        return ok, shown

    # ----- ovoz -----
    def speak(self, text):
        try:
            from jnius import autoclass
            PA = autoclass("org.kivy.android.PythonActivity")
            TTS = autoclass("android.speech.tts.TextToSpeech")
            Locale = autoclass("java.util.Locale")
            if not hasattr(self, "_tts"):
                self._tts = TTS(PA.mActivity, None)
            self._tts.setLanguage(Locale.GERMAN)
            self._tts.speak(text, TTS.QUEUE_FLUSH, None)
        except Exception:
            try:
                from plyer import tts
                tts.speak(text)
            except Exception:
                pass
